package com.cg.payroll.beans;

public class Salary {
	private int basicSalary,personalAllowance, epf,companyPf;
	private float hra, conveyenceAllowance, otherAllowance,grossSalary,netSalary,monthlyTax,gratuity;
	public Salary() {
	}
	
	
	public Salary(int basicSalary, int personalAllowance, int epf, int companyPf, float hra, float conveyenceAllowance,
			float otherAllowance, float grossSalary, float netSalary, float monthlyTax, float gratuity) {
		super();
		this.basicSalary = basicSalary;
		this.personalAllowance = personalAllowance;
		this.epf = epf;
		this.companyPf = companyPf;
		this.hra = hra;
		this.conveyenceAllowance = conveyenceAllowance;
		this.otherAllowance = otherAllowance;
		this.grossSalary = grossSalary;
		this.netSalary = netSalary;
		this.monthlyTax = monthlyTax;
		this.gratuity = gratuity;
	}


	public Salary(int basicSalary, int epf, int companyPf) {
		super();
		this.basicSalary = basicSalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}


	public int getBasicSalary() {
		return basicSalary;
	}


	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}


	public int getPersonalAllowance() {
		return personalAllowance;
	}


	public void setPersonalAllowance(int personalAllowance) {
		this.personalAllowance = personalAllowance;
	}


	public int getEpf() {
		return epf;
	}


	public void setEpf(int epf) {
		this.epf = epf;
	}


	public int getCompanyPf() {
		return companyPf;
	}


	public void setCompanyPf(int companyPf) {
		this.companyPf = companyPf;
	}


	public float getHra() {
		return hra;
	}


	public void setHra(float hra) {
		this.hra = hra;
	}


	public float getConveyenceAllowance() {
		return conveyenceAllowance;
	}


	public void setConveyenceAllowance(float conveyenceAllowance) {
		this.conveyenceAllowance = conveyenceAllowance;
	}


	public float getOtherAllowance() {
		return otherAllowance;
	}


	public void setOtherAllowance(float otherAllowance) {
		this.otherAllowance = otherAllowance;
	}


	public float getGrossSalary() {
		return grossSalary;
	}


	public void setGrossSalary(float grossSalary) {
		this.grossSalary = grossSalary;
	}


	public float getNetSalary() {
		return netSalary;
	}


	public void setNetSalary(float netSalary) {
		this.netSalary = netSalary;
	}


	public float getMonthlyTax() {
		return monthlyTax;
	}


	public void setMonthlyTax(float monthlyTax) {
		this.monthlyTax = monthlyTax;
	}


	public float getGratuity() {
		return gratuity;
	}


	public void setGratuity(float gratuity) {
		this.gratuity = gratuity;
	}

	
	}
