package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetail;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {
	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl() {
		daoServices=new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,String department,String designation,
			String pancard,int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode){
	
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetail(accountNumber, bankName, ifscCode)));
	}
	public int calculateNetSalary(int associateId){
		Associate associate=this.getAssociateDetails(associateId);
		if(associate!=null){
			associate.getSalary().setPersonalAllowance((int)0.3*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance((int)0.2*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance((int)0.1*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra((int)0.25*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity((int)0.5*associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(associate.getSalary().getPersonalAllowance()+associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			int annualSalary=associate.getSalary().getBasicSalary()*12;
			int taxableSalary;
			int nonTaxableSalary=associate.getYearlyInvestmentUnder80C()+(associate.getSalary().getEpf()*12)+(associate.getSalary().getCompanyPf()*12);
			if(nonTaxableSalary<150000)
				nonTaxableSalary=nonTaxableSalary;
			else
				nonTaxableSalary=150000;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			//return ;
		}
		return 0;
	}
	public Associate getAssociateDetails(int associateId){
		Associate associate=daoServices.getAssociate(associateId);
		return associate;
	}
	public Associate[] getAllAssociateDetails(){
		Associate[] associates=daoServices.getAssociates();
		return associates;
	}
}
